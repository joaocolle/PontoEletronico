import { Component, OnInit } from '@angular/core';
import { Login } from '../../../classes/login';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})

export class LoginComponent implements OnInit{

  public login: any = {};

  constructor(
    private router: Router
  ){}

  /*Metodo que inicia com o componente*/
  ngOnInit(): void {
    this.login = new Login();
  }

  /*Logica de autenticação do login que faz o rotiamento automático*/
  public fazerLogin() : void {
    
    console.log(this.login.usuario, this.login.senha)

    this.router.navigate(['dashboard']);
  }
}





