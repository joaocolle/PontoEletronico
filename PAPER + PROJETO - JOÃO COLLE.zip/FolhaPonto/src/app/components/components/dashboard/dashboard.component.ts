import { Component } from '@angular/core';
import { HttpClient} from '@angular/common/http'; //permitir a comunicação HTTP.
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss'
})

export class DashboardComponent {

    routeName: string = 'dashboard';
  
    pontoRegistrado: any = {};

    constructor(private http: HttpClient, private router: Router) {};

    public marcarPonto() : void {

      //Obter a data e hora atuais
      const dataHoraAtual = new Date();

      //Formatar a data e registra a informação nem 'pontoRegistrado'
      this.formatarDataHora(dataHoraAtual);
    
      //Testar se objeto JSON
      console.log(this.pontoRegistrado);

      //enviar dados para o backend
      this.enviarDadosParaBackend(this.pontoRegistrado).subscribe(
        (response) => {
          console.log('Dados enviados com sucesso para o backend:', response);
        },
        (error) => {
          console.error('Erro ao enviar dados para o backend:', error);
        }
      );

    }

    formatarDataHora(dataHoraAtual: Date): void {
      const options: Intl.DateTimeFormatOptions = {
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit'
      };

      const dataHoraFormatada = new Intl.DateTimeFormat('pt-BR', options).format(dataHoraAtual);
      const [dia, mes, ano, hora, minutos] = dataHoraFormatada.split(/[\s\/,:]+/);
  
      //define os atributos do objeto pontoRegistrado
      this.pontoRegistrado = {
        "dia": parseInt(dia),
        "mes": parseInt(mes),
        "ano": parseInt(ano),
        "hora": parseInt(hora),
        "minutos": parseInt(minutos)
        };
}

enviarDadosParaBackend(data: any) {
  const ponto = 'http://localhost:8080/marcarPonto';
  return this.http.post(ponto, data);
}

public espelho() : void {

  this.router.navigate(['espelho']);
}

}
