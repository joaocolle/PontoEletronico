import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http'; //Permitir a comunicação HTTP.
import { Router } from '@angular/router';

@Component({
  selector: 'app-espelho',
  templateUrl: './espelho.component.html',
  styleUrl: './espelho.component.scss'
})

export class EspelhoComponent {

  routeName: string = 'dashboard';

  months = [
    { name: 'Janeiro 2025', value: 1 },
    { name: 'Fevereiro 2025', value: 2 },
    { name: 'Março 2025', value: 3 },
    { name: 'Abril 2025', value: 4 },
    { name: 'Maio 2025', value: 5 },
    { name: 'Junho 2025', value: 6 },
    { name: 'Julho 2025', value: 7 },
    { name: 'Agosto 2025', value: 8 },
    { name: 'Setembro 2025', value: 9 },
    { name: 'Outubro 2025', value: 10 },
    { name: 'Novembro 2025', value: 11 },
    { name: 'Dezembro 2025', value: 12 }
];

mes: number = 0;
pontos: any[] = [];

constructor(private http: HttpClient, private router: Router) {
    //Define o mês atual como selecionado por padrão:
    //this.mes = new Date().getMonth() + 1; // Meses em JavaScript começam de 0
}

// Lógica a ser executada quando o mês selecionado mudar
alterarMes() {

    console.log('Mês selecionado:', this.mes);
  
    const endpoint = `http://localhost:8080/espelho/${this.mes}`;

    this.http.get<any[]>(endpoint).subscribe(
      (response) => {
          this.pontos = response as any //Conversão explícita do tipo de response para any[]
          console.log('Pontos recebidos:', this.pontos);
      },
      (error) => {
          console.error('Erro ao obter dados do backend:', error);
      }
  );

} 

editarPonto(idPonto: any, dia: any, mes: any, ano: any) {

  console.log("Editar ponto com id:", idPonto, "Dia:", dia,"mes:", mes, "ano:", ano);

  let novaHoraString = prompt("Digite a nova hora:");
  let novosMinutosString = prompt("Digite os novos minutos:");

  // Verifique se o valor retornado pelo prompt é nulo
  if (novaHoraString !== null && novosMinutosString !== null) {
      // Faça o que precisa com os novos valores de hora e minutos
      let novaHora = parseInt(novaHoraString);
      let novosMinutos = parseInt(novosMinutosString);
      console.log('Nova hora:', novaHoraString);
      console.log('Novos minutos:', novosMinutosString);

      // Crie um objeto com os dados a serem enviados no corpo da requisição
      const body = {
        "dia": dia,
        "mes": mes,
        "ano": ano,
        "hora": novaHora,
        "minutos": novosMinutos
    };

    console.log("Ponto atualizado:", body)

        this.http.put(`http://localhost:8080/editarPonto/${idPonto}`, body)
            .subscribe(
                response => {
                    console.log('Atualização bem-sucedida:', response);
                },
                error => {
                    console.error('Erro ao atualizar ponto:', error);
                }
            );
    } else {
      console.error('Valores de hora ou minutos inválidos.');
    } 

  }

  deletarPonto(idPonto: any){

    console.log("Deletar ponto com id:", idPonto)

    this.http.delete(`http://localhost:8080/deletePonto/${idPonto}`, { responseType: 'text' }).subscribe(
      () => {
        console.log('Exclusão bem-sucedida');
      },
      error => {
        console.error('Erro ao excluir ponto:', error);
      }
    );
  }

  public dashboard() : void {

    this.router.navigate(['dashboard']);
  }
}



  
