import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/components/login/login.component';
import { DashboardComponent } from './components/components/dashboard/dashboard.component';
import { EspelhoComponent } from './components/components/espelho/espelho.component';

const routes: Routes = [
  {path: '', component:LoginComponent},
  {path: 'dashboard', component: DashboardComponent},
  {path: 'espelho', component: EspelhoComponent}
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
