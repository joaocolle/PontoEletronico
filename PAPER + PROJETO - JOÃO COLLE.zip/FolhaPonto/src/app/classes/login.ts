//Classe para efetuar o Login
export class Login {
    public usuario: String;
    public senha: string;
  
    constructor() {
        this.usuario = '';
        this.senha = '';
    }
  }