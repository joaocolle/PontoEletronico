package com.example.springboot.repositories;

import com.example.springboot.models.ModeloPonto;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;
@Repository

public interface PontoRepository extends JpaRepository <ModeloPonto, UUID> {

    //Caso seja uma consulta mais complexa, poderá utilizar o metodo '@Query'
    List<ModeloPonto> findByMes(int mes);
}

/*Esse código define um repositório JPA para a entidade ModeloPonto,
permitindo operações CRUD básicas sobre essa entidade usando Spring Data JPA em um aplicativo Spring Boot.*/