package com.example.springboot.models;

import java.io.Serializable;
import java.util.UUID;
import jakarta.persistence.*;

@Entity
@Table(name = "TB-PONTO")

public class ModeloPonto implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)

    private UUID idPonto;
    private Integer dia;
    private Integer mes;
    private Integer ano;
    private Integer hora;
    private Integer minutos;

    public UUID getIdPonto() {
        return idPonto;
    }

    public void setIdPonto(UUID idPonto) {
        this.idPonto = idPonto;
    }

    public Integer getDia() {
        return dia;
    }

    public void setDia(Integer dia) {
        this.dia = dia;
    }

    public Integer getMes() {
        return mes;
    }

    public void setMes(Integer mes) {
        this.mes = mes;
    }

    public Integer getAno() {
        return ano;
    }

    public void setAno(Integer ano) {
        this.ano = ano;
    }

    public Integer getHora() {
        return hora;
    }

    public void setHora(Integer hora) {
        this.hora = hora;
    }

    public Integer getminutos() {
        return minutos;
    }

    public void setminutos(Integer minutos) {
        this.minutos = minutos;
    }
}
