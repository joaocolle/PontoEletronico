package com.example.springboot;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class CorsConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
                .allowedOrigins("http://localhost:4200") // Permitir solicitações de origem específica (seu aplicativo Angular em desenvolvimento)
                .allowedMethods("GET", "POST", "PUT", "DELETE") // Permitir métodos HTTP específicos
                .allowCredentials(true) // Permitir credenciais (por exemplo, cookies)
                .maxAge(3600); // Cache de preflight por 1 hora
    }
}