package com.example.springboot.controllers;

import com.example.springboot.dtos.PontoRecordDto;
import com.example.springboot.models.ModeloPonto;
import com.example.springboot.repositories.PontoRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.*;
//import jakarta.validation.Valid;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;


@RestController
public class PontoController {

    @Autowired
    PontoRepository pontoRepository;

    @PostMapping("/marcarPonto")
    public ResponseEntity<ModeloPonto> savePonto(@RequestBody PontoRecordDto pontoRecordDto){
        var modeloPonto = new ModeloPonto();
        BeanUtils.copyProperties(pontoRecordDto, modeloPonto);
        return ResponseEntity.status(HttpStatus.CREATED).body(pontoRepository.save(modeloPonto));
    }

    @GetMapping("/espelho/{mes}")
    public ResponseEntity<List<ModeloPonto>> getPonto(@PathVariable int mes) {
        List<ModeloPonto> modelosPontos = pontoRepository.findByMes(mes);
        return ResponseEntity.status(HttpStatus.OK).body(modelosPontos);
    }

    @PutMapping("/editarPonto/{id}")
    public ResponseEntity<Object> updatePonto(@PathVariable UUID id, 
                                              @RequestBody PontoRecordDto pontoRecordDto){
    Optional<ModeloPonto> ponto0 = pontoRepository.findById(id);
    if (ponto0.isEmpty()) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Ponto não encontrado");
    }
    var modeloPonto = ponto0.get();
    BeanUtils.copyProperties(pontoRecordDto, modeloPonto);
    return ResponseEntity.status(HttpStatus.OK).body(pontoRepository.save(modeloPonto));
    }

    @DeleteMapping("/deletePonto/{id}")
    public ResponseEntity<Object> deletePonto(@PathVariable UUID id){
        Optional<ModeloPonto> ponto0 = pontoRepository.findById(id);
        if (ponto0.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Ponto não encontrado");
        }
        pontoRepository.delete(ponto0.get());
        return ResponseEntity.status(HttpStatus.OK).body("Ponto deletado com sucesso");
    }

}
