package com.example.springboot.dtos;

//import jakarta.validation.constraints.NotNull;

public record PontoRecordDto (Integer dia,Integer mes, Integer ano,Integer hora,Integer minutos) {
}